//kpm.h
#ifndef KPM_H
#define KPM_H

#include "types.h"

void Init_KPM(void);
char KeyScan(void);
void ReadNum(u32 *num, u8 *key);

#endif
