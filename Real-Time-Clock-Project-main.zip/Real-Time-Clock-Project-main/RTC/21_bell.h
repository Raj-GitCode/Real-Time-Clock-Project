#ifndef BELL_H
#define BELL_H

void Create_Bell_Symbol(void);
void Show_Bell_On_LCD(void);

#endif
